
const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("optionText"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
   { question : "Inside which HTML element do we put the Javascript?",
    choice1 : "<script>",
    choice2 : "<javascript>",
    choice3 : "<js>",
    choice4 : "<scripting>",
    answer : 1
   },
    {
      question : "What is the correct syntax for referring to an external script called 'xxx.js'?",
    choice1 : "<script href='xxx.js'>",
    choice2 : "<script name='xxx.js'>",
    choice3 : "<script src='xxx.js'>",
    choice4 : "<script file='xxx.js'>",
    answer : 3
    },
    {
     question : "How do you write 'Hello World' in an alert box?",
    choice1 : "msgBox('Hello World');",
    choice2 : "alertBox('Hello World');",
    choice3 : "msg('Hello World');",
    choice4 : "alert('Hello World');",
    answer : 4
  },
    {
     question : "From which tag descriptive list starts?",
    choice1 : "<LL>",
    choice2 : "<DD>",
    choice3 : "<DL>",
    choice4 : "<DS",
    answer : 3
  },
  {
   question : "Choose the correct HTML tag for the largest heading",
  choice1 : "<heading>",
  choice2 : "<h6>",
  choice3 : "<head>",
  choice4 : "<h1>",
  answer : 4
},{
 question : "What is the correct HTML tag for inserting a line break?",
choice1 : "<br>",
choice2 : "<lb>",
choice3 : "<break>",
choice4 : "<brk>",
answer : 1
},
{
 question : "Which of these tags are all <table> tags?",
choice1 : "<table> <head> <tfoot>",
choice2 : "<table> <tr> <td>",
choice3 : "<body> <head> <tfoot>",
choice4 : "<table> <tr> <tt>",
answer : 2
},
{
 question : "How can you make a numbered list?",
choice1 : "<ol>",
choice2 : "<ul>",
choice3 : "<dl>",
choice4 : "<list>",
answer : 1
},
{
 question : "What is the correct HTML for making a checkbox?",
choice1 : "<checkbox>",
choice2 : "<input type>",
choice3 : "<check>",
choice4 : "<input type>",
answer : 2
},
{
 question : "What does CSS stands for?",
choice1 : "Creative Style Sheets",
choice2 : "Cascading Style Sheets",
choice3 : "Computer Style Sheets",
choice4 : "Colorful Style Sheets",
answer : 2
},
{
 question : "Which property is used to change the background color?",
choice1 : "color",
choice2 : "background-color",
choice3 : "bgcolor",
choice4 : "bg-color",
answer : 2
},
{
 question : "Which property is used to change the left margin of an element?",
choice1 : "padding-left",
choice2 : "margin-left",
choice3 : "indent",
choice4 : "space-left",
answer : 2
},
{
 question : "Which sign does jQuery use as a Shortcut for jQuery?",
choice1 : "the ? sign",
choice2 : "the # sign",
choice3 : "the $ sign",
choice4 : "the / sign",
answer : 3
},
{
 question : "Which jQuery method is used to hide selected elements?",
choice1 : "hidden()",
choice2 : "visible(false)",
choice3 : "hide()",
choice4 : "display(none)",
answer : 3
},
{
 question : "Which of the following method of Boolean object returns a string depending upon the value of the object?",
choice1 : "toString()",
choice2 : "toSource()",
choice3 : "valueOf()",
choice4 : "None",
answer : 3
},
{
 question : "Which built-in method returns the character at the specified index?",
choice1 : "characterAt()",
choice2 : "getCharAt()",
choice3 : "charAt()",
choice4 : "None",
answer : 3
},
{
 question : "HTML stand for?",
choice1 : "Hyper Link and Text Markup Language",
choice2 : "Hyper Tool Markup Language",
choice3 : "Home Tool Markup Language",
choice4 : "Hyper Text Markup Language",
answer : 4
},
{
 question : "Which of the following code creates an object?",
choice1 : "var book = Object()",
choice2 : "var book = new Object()",
choice3 : "var book = new OBJECT()",
choice4 : "var book = new Book()",
answer : 2
},
{
 question : "Which of the following function of String object is used to match a regular expression against a string?",
choice1 : "concat()",
choice2 : "match()",
choice3 : "search()",
choice4 : "replace()",
answer : 2
},
{
 question : "Which of the following function of String object causes a string to be displayed in a small font, as if it were in a <small> tag?",
choice1 : "link()",
choice2 : "small()",
choice3 : "sup()",
choice4 : "sub()",
answer : 2
}

];

//constants
const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    console.log(availableQuestions);
    getNewQuestion();
};

getNewQuestion = () => {
    if(availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS){
      localStorage.setItem("mostRecentScore", score);
        //go to the end page
        return window.location.assign("WEB-DEVELOPMENT.html");
    }
    questionCounter++;
    progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
    //update the progress bar
    progressBarFull.style.width = `${(questionCounter/MAX_QUESTIONS)*100}%`;
    const questionIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });
    availableQuestions.splice(questionIndex, 1);
    acceptingAnswers = true;
};

choices.forEach(choice => {
    choice.addEventListener("click", e =>{
        if(!acceptingAnswers) return;
        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];
        const classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';
        if(classToApply === "correct"){
          incrementScore(CORRECT_BONUS);
        }
      selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(() => {
        selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        },1000);

    });
});


incrementScore = num =>{
  score += num;
  scoreText.innerText = score;
};
startGame();
