const username = document.getElementById("username");
const saveScoreBtn = document.getElementById("saveScoreBtn");
const mostRecentScore = localStorage.getItem("mostRecentScore");
const finalScore = document.getElementById("finalScore");
const highScores = JSON.parse(localStorage.getItem("highScores")) || [];

const MAX_HIGH_SCORES =5;


finalScore.innerText = mostRecentScore;
var url = window.location.pathname;
var filename = url.substring(url.lastIndexOf('/')+1, url.length - 5);
username.addEventListener("keyup", () => {
  saveScoreBtn.disabled = !username.value;
});


if (mostRecentScore < 8){
  document.getElementById("message").innerHTML = "Unfortunately you did not pass the test. Please try again later!";

}
else{
    document.getElementById("message").innerHTML = "You have successfully passed the test. You are now certified in " + filename;
}

saveHighScore = e => {
  console.log("clicked the save button!");
  e.preventDefault();



  const score = {
    score : mostRecentScore,
    name : username.value
  };
  highScores.push(score);
  highScores.sort((a,b) => b.score - a.score);
  highScores.splice(5);

  localStorage.setItem("highScores", JSON.stringify(highScores));
window.location.assign("highscore.html");


};
