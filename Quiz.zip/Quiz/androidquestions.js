
const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("optionText"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
   { question : "How to get a response from an activity in Android?",
    choice1 : "startActivityToResult()",
    choice2 : "startActivityForResult()",
    choice3 : "Bundle()",
    choice4 : "None",
    answer : 2
   },
    {
      question : "Which of the following is/are the subclasses in Android?",
    choice1 : "Action Bar Activity",
    choice2 : "Launcher Activity",
    choice3 : "Preference Activity",
    choice4 : "All of above",
    answer : 4
    },
    {
     question : "What are the return values of onStartCommand() in android services?",
    choice1 : "START_STICKY",
    choice2 : "START_NOT_STICKY",
    choice3 : "START_REDELIVER_INTENT",
    choice4 : "All of the above",
    answer : 4
  },
    {
      question : "What is the use of content provider in Android?",
    choice1 : "To send the data from an application to another application",
    choice2 : "To store the data in a database",
    choice3 : "To store the data between application",
    choice4 : "None",
    answer : 3
    },
    {
      question : "Is it possible activity without UI in Android?",
    choice1 : "No, it's not possible",
    choice2 : "Yes, it's possible",
    choice3 : "We can't say",
    choice4 : "None",
    answer : 2
    },
    {
      question : "What is the application class in Android?",
    choice1 : "Base class for all classes",
    choice2 : "A class that can create only an object",
    choice3 : "Anonymous class",
    choice4 : "Java class",
    answer : 1
    },
    {
      question : "what is GCM in Android?",
    choice1 : "Google Could Messaging for chrome",
    choice2 : "Google Count Messaging",
    choice3 : "Google Message pack",
    choice4 : "None",
    answer : 1
    },
    {
      question : "What is DDMS in Android?",
    choice1 : "Dalvik memory server",
    choice2 : "Device memory server",
    choice3 : "Dalvik monitoring services",
    choice4 : "Dalvik debug monitor services",
    answer : 4
    },
    {
      question : "In which technique, we can refresh the dynamic content in Android?",
    choice1 : "Java",
    choice2 : "Ajax",
    choice3 : "Android",
    choice4 : "None",
    answer : 2
    },
    {
      question : "What is bean class in Android?",
    choice1 : "A class used to hold states and objects",
    choice2 : "A bean clas can be passed from one activity to another",
    choice3 : "A mandatory class in android",
    choice4 : "None",
    answer : 1
  },
  { question : "In which Directory XML Layout Files are stored?",
   choice1 : "/assets",
   choice2 : "/src",
   choice3 : "/res/values",
   choice4 : "/res/layout",
   answer : 4
  },
   {
     question : "Which code used by android is not an open sourec?",
   choice1 : "Video Driver",
   choice2 : "Wifi Driver",
   choice3 : "Device Driver",
   choice4 : "Bluetooth Driver",
   answer : 2
   },
   {
    question : "How many levels of securities are in android?",
   choice1 : "Android Level Security",
   choice2 : "App And Kernel Level Security",
   choice3 : "Java Level Security",
   choice4 : "None",
   answer : 2
 },
   {
     question : "Which of the following does not belong to transitions?",
   choice1 : "ViewFlipper",
   choice2 : "ViewAnimator",
   choice3 : "ViewSwitcher",
   choice4 : "ViewSlider",
   answer : 4
   },
   {
     question : "What are the functionalities in Async Task in Android?",
   choice1 : "OnPreExecution()",
   choice2 : "OnPostExecution()",
   choice3 : "DoInBackground()",
   choice4 : "OnProgressUpdate()",
   answer : 2
   },
   {
     question : "What does AAPT stands for?",
   choice1 : "Android Asset Processing Tool",
   choice2 : "Android Asset Providing Tool",
   choice3 : "Android Asset Packaging Tool",
   choice4 : "Android Asset packaging Technique",
   answer : 3
   },
   {
     question : "View Pager is Used For?",
   choice1 : "Swiping Activities",
   choice2 : "Swiping Fragments",
   choice3 : "Paging Down List Items",
   choice4 : "None",
   answer : 2
   },
   {
     question : "What is JNI in Android?",
   choice1 : "Java Interface",
   choice2 : "Java Native Interface",
   choice3 : "Java Network Interface",
   choice4 : "Image Editable Tool",
   answer : 2
   },
   {
     question : "which programming language is used for android application development?",
   choice1 : "Java",
   choice2 : "NodeJs",
   choice3 : "JSX",
   choice4 : "PHP",
   answer : 1
   },
   {
     question : "Action Bar can be associated to?",
   choice1 : "Only Fragments",
   choice2 : "Only Activities",
   choice3 : "Both",
   choice4 : "None",
   answer : 2
   }
];

//constants
const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    console.log(availableQuestions);
    getNewQuestion();
};

getNewQuestion = () => {
    if(availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS){
      localStorage.setItem("mostRecentScore", score);
        //go to the end page
        return window.location.assign("ANDROID.html");
    }
    questionCounter++;
    progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
    //update the progress bar
    progressBarFull.style.width = `${(questionCounter/MAX_QUESTIONS)*100}%`;
    const questionIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });
    availableQuestions.splice(questionIndex, 1);
    acceptingAnswers = true;
};

choices.forEach(choice => {
    choice.addEventListener("click", e =>{
        if(!acceptingAnswers) return;
        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];
        const classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';
        if(classToApply === "correct"){
          incrementScore(CORRECT_BONUS);
        }
      selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(() => {
        selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        },1000);

    });
});


incrementScore = num =>{
  score += num;
  scoreText.innerText = score;
};
startGame();
