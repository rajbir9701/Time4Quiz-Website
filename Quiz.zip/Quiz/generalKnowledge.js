
const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("optionText"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
   { question : "Which civil rights activist was famous for refusing to give up her seat on a bus?",
    choice1 : "Dorothy Day",
    choice2 : "Rosa Parks",
    choice3 : "Jane Fonda",
    choice4 : "Emma Willard",
    answer : 2
   },
    {
      question : "Who was the original king of rock n roll?",
    choice1 : "Michael Jackson",
    choice2 : "Mick Jagger",
    choice3 : "Elvis Presley",
    choice4 : "Steven Tyler",
    answer : 3
    },
    {
     question : "Agent 007, featured in many movies dating back to 1962, is known as ____ Bond?",
    choice1 : "John",
    choice2 : "Benedict",
    choice3 : "James",
    choice4 : "Elizier",
    answer : 3
  },
  {
    question : "What flightless bird went extinct in the 1660s and has a reputation for stupidity?",
  choice1 : "The dodo bird",
  choice2 : "The Labrador duck",
  choice3 : "The laughing owl",
  choice4 : "The passenger pigeon",
  answer : 1
  },
  {
    question : "What plant is traditionally the primary ingredient in wine?",
  choice1 : "Agave",
  choice2 : "Grape",
  choice3 : "Peach",
  choice4 : "Plum",
  answer : 2
  },
  {
    question : "The human brain communicates with the rest of the body through networks of what?",
  choice1 : "Tendors",
  choice2 : "Nerves",
  choice3 : "Muscles",
  choice4 : "Lipids",
  answer : 2
  },
  {
    question : "What chemical is added to U.S. water supplies in the hope of improving dental health?",
  choice1 : "Chlorine",
  choice2 : "Fluoride",
  choice3 : "Bromine",
  choice4 : "Hydrogen",
  answer : 2
  },
  {
    question : "Which of these was not one of Snow White's seven dwarfs?",
  choice1 : "Dopey",
  choice2 : "Sappy",
  choice3 : "Sneezy",
  choice4 : "Grumpy",
  answer : 2
  },
  {
    question : "Netwon is said to have been inspired by what to describe the theory of gravity?",
  choice1 : "Ladder",
  choice2 : "Hailstone",
  choice3 : "Apple",
  choice4 : "Rock",
  answer : 3
  },
  {
    question : "What is the head of the Roman Catholic Church called?",
  choice1 : "Master",
  choice2 : "Cardinal",
  choice3 : "Preacher",
  choice4 : "Pope",
  answer : 4
},
{ question : "Which U.S. president is thought to have taught himself how to read and write ?",
 choice1 : "Woodrow Wilson",
 choice2 : "Abraham Lincoln",
 choice3 : "Theodore Roosevelt",
 choice4 : "John Adams",
 answer : 2
},
 {
   question : "Which English King was famous for beheading his wives?",
 choice1 : "King Henry VIII",
 choice2 : "King Edward I",
 choice3 : "King James III",
 choice4 : "King Alfred the Great",
 answer : 1
 },
 {
  question : "According to the Big Bang Theory, how did the universe begin?",
 choice1 : "A rain storm",
 choice2 : "An explosion",
 choice3 : "A slow, calm expansion",
 choice4 : "A meteor shower",
 answer : 2
},
{
 question : "In the ILiad, Greek forces besiege the people of what kingdom?",
choice1 : "Persia",
choice2 : "Troy",
choice3 : "Babylon",
choice4 : "Paris",
answer : 2
},
{
 question : "Which American town was famous for its witch trials?",
choice1 : "Nashville,TN",
choice2 : "Charleston,SC",
choice3 : "Salem,MA",
choice4 : "Portland,OR",
answer : 3
},
{
 question : "Yellowstone National Park is in which of the following states?",
choice1 : "California",
choice2 : "Ohio",
choice3 : "Wyoming",
choice4 : "Georgia",
answer : 3
},
{
 question : "Which of the following is not an island in Hawaii?",
choice1 : "Maui",
choice2 : "Oahu",
choice3 : "Kauai",
choice4 : "Mauna Loa",
answer : 3
},
{
 question : "Which of these foods was invented in Australia?",
choice1 : "Vegemite",
choice2 : "Pizza",
choice3 : "Hot Dogs",
choice4 : "Croissant",
answer : 1
},
{
 question : "Digestion typically releases what chemical that makes you happy?",
choice1 : "Serotonin",
choice2 : "Melatonin",
choice3 : "Ghrelin",
choice4 : "Aldosterone",
answer : 1
},
{
 question : "In the Harry Potter series, Harry must battle which evil wizard?",
choice1 : "Voldemort",
choice2 : "Grindelward",
choice3 : "Dumbledore",
choice4 : "Sirius Black",
answer : 1
}
];

//constants
const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 10;

startGame = () => {
    questionCounter = 0;
    score = 0;
    availableQuestions = [...questions];
    console.log(availableQuestions);
    getNewQuestion();
};

getNewQuestion = () => {
    if(availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS){
      localStorage.setItem("mostRecentScore", score);
        //go to the end page
        return window.location.assign("GENERAL-KNOWLEDGE.html");
    }
    questionCounter++;
    progressText.innerText = `Question ${questionCounter}/${MAX_QUESTIONS}`;
    //update the progress bar
    progressBarFull.style.width = `${(questionCounter/MAX_QUESTIONS)*100}%`;
    const questionIndex = Math.floor(Math.random() * availableQuestions.length);
    currentQuestion = availableQuestions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });
    availableQuestions.splice(questionIndex, 1);
    acceptingAnswers = true;
};

choices.forEach(choice => {
    choice.addEventListener("click", e =>{
        if(!acceptingAnswers) return;
        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];
        const classToApply = selectedAnswer == currentQuestion.answer ? 'correct' : 'incorrect';
        if(classToApply === "correct"){
          incrementScore(CORRECT_BONUS);
        }
      selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(() => {
        selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        },1000);

    });
});


incrementScore = num =>{
  score += num;
  scoreText.innerText = score;
};
startGame();
